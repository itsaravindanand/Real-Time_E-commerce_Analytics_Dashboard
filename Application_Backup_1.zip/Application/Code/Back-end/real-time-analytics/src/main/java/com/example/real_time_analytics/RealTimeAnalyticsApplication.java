package com.example.real_time_analytics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RealTimeAnalyticsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RealTimeAnalyticsApplication.class, args);
	}

}
