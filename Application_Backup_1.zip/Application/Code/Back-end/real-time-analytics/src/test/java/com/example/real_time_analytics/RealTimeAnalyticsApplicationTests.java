package com.example.real_time_analytics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RealTimeAnalyticsApplicationTests {

	@Test
	void contextLoads() {
	}

}
